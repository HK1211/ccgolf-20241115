package com.ccgolf.sharedCodeService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SharedCodeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
